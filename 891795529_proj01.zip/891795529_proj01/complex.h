/**
 * A class that describes a complex equation.
 * @author William Duncan, Anindo Hazra
 * operators (+, -, *, /, <<)
 * </pre>
 * File: complex.h
 * Date: 22 February 2023
 * Course: CSc 1254
 * Instructor: Dr. Duncan
 * </pre>
 */	

#ifndef Complex_H
#define Complex_H

#include <iostream>
#include <cmath>

using namespace std;


/**
 * A class that defines complex numbers 
 * and operations using complex numbers 
 */

class Complex
{
	private:
	
	/**
	 * real variable of complex
	 */
	 
	double real;
	
	/**
	 * imag variable of complex
	 */
	 
	double imag;


	public:
	
	/**
	 * Default constructor that makes a complex number
	 */
	 
	Complex();
	
	/**
    * A parameterized constructor that makes an equation using
    * the parameters
    * @param r = real
    */
    
	Complex(double r);
	
	/**
    * A parameterized constructor that makes an equation using
    * the parameters
    * @param r = real
    * @param i = imaginary
    */
    
	Complex(double r, double i);
	
	/**
    * Gives the real part of equation.
    * @return the real part of equation
    */
    
	double getReal() const;

    /**
    * Gives the imaginary part of equation.
    * @return the imaginary part of equation
    */
    
	double getImag() const;
	
	/**
    * Calculates and gives the conjugate of complex equation
    * @return the conjugate of complex equation
    */
    
	Complex conjugate();

    /**
    * Calculates and gives the modulus of complex equation
    * @return z - the modulus of complex equation
    */
    
	Complex modulus() const;
	
	/**
    * calculates and gives the argument of complex equation
    * @throw -2 if real = 0 and imag = 0
    * @return atan2 - the argument of complex equation
    */
    
	double argument() const;
	
	/**
    * Adds power over whole complex equation
    * @param z - constant reference to complex equation
    * @param n - power value
    * @return ans 
    */
    
	friend Complex pow(const Complex& z, int n); 
	
	/**
    * overloaded + operator
    * @param z1 - first complex equation, a constant reference 
    * to a Complex object
    * @param z2 - second complex equation, a constant reference 
    * to a Complex object
    * @return a Complex object adding two complex equations
    */
    
	friend Complex operator +(const Complex& z1, const Complex& z2); 
	
	/**
    * overloaded * operator
    * @param z1 - first complex equation, a constant reference 
    * to a Complex object
    * @param z2 - second complex equation, a constant reference 
    * to a Complex object
    * @return a Complex object multiplying two complex equations
    */
    
	friend Complex operator *(const Complex& z1, const Complex& z2);
	
	/**
    * overloaded - operator
    * @param z1 - first complex equation, a constant reference 
    * to a Complex object
    * @param z2 - second complex equation, a constant reference 
    * to a Complex object
    * @return a Complex object subtracting two complex equations
    */
    
	friend Complex operator -(const Complex& z1, const Complex& z2);
	
	/**
    * overloaded / operator
    * @param z1 - first complex equation, a constant reference 
    * to a Complex object
    * @param z2 - second complex equation, a constant reference 
    * to a Complex object
    * @return a Complex object dividing two complex equations
    */
    
	friend Complex operator /(const Complex& z1, const Complex& z2);
	
	/**
    * overloaded << operator
    * @param out - output, ostream reference to imaginary part of equation,
    * adds i to imaginary part
    * @param z - complex equation, a constant reference 
    * to a Complex object
    * @return a Complex object adding two complex equations
    */
    
	friend ostream& operator<<(ostream& out, const Complex& z);
};

#endif
